//
//  ViewController.swift
//  LayoutAnchorTwo
//
//  Created by padalingam agasthian on 15/03/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Any one method should be called
         exampleOneNSLayoutConstraint()
         //exampleOneNSLayoutAnchor()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func exampleOneNSLayoutConstraint()
    {
        let customView:UIView = UIView();
        customView.backgroundColor = UIColor.magentaColor()
        view.addSubview(customView)
        let heightContraints = NSLayoutConstraint(item: customView, attribute:
            .Leading, relatedBy: .Equal, toItem: view,
            attribute: .Leading, multiplier: 1.0,
            constant: 70)
        let widthContraints = NSLayoutConstraint(item: customView, attribute:
            .Trailing, relatedBy: .Equal, toItem: view,
            attribute: .Trailing, multiplier: 1.0,
            constant: -70)
        let topConstraint = NSLayoutConstraint(item: customView, attribute:
            .Top, relatedBy: .Equal, toItem: view,
            attribute: .Top, multiplier: 1.0,
            constant: 70)
        let bottomConstraint = NSLayoutConstraint(item: customView, attribute:
            .Bottom, relatedBy: .Equal, toItem: view,
            attribute: .Bottom, multiplier: 1.0,
            constant: -150)
        
        customView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activateConstraints([heightContraints,widthContraints,topConstraint,bottomConstraint])
        
    }
    
    func exampleOneNSLayoutAnchor()
    {
        let customView:UIView = UIView();
        customView.backgroundColor = UIColor.redColor()
        view.addSubview(customView)
        customView.translatesAutoresizingMaskIntoConstraints = false
        customView.leadingAnchor.constraintEqualToAnchor(view.leadingAnchor, constant: 70).active = true
        customView.trailingAnchor.constraintEqualToAnchor(view.trailingAnchor, constant: -70).active = true
        customView.topAnchor.constraintEqualToAnchor(view.topAnchor, constant: 70).active = true
        customView.bottomAnchor.constraintEqualToAnchor(view.bottomAnchor, constant: -150).active = true
    }
    

}

