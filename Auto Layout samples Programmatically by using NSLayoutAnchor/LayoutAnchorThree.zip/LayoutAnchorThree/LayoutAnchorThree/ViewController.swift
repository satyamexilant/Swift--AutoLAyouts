//
//  ViewController.swift
//  LayoutAnchorThree
//
//  Created by padalingam agasthian on 15/03/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Any one method should be called
         exampleTwoNSLayoutConstraint()
        //exampleTwoNSLayoutAnchor()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func exampleTwoNSLayoutAnchor()
    {
        let space = UILayoutGuide()
        view.addLayoutGuide(space)
        let customView:UIView = UIView();
        customView.backgroundColor = UIColor.magentaColor()
        view.addSubview(customView)
        customView.translatesAutoresizingMaskIntoConstraints = false
        let secondView = UIView()
        secondView.backgroundColor = UIColor.greenColor()
        secondView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(secondView)
        customView.leadingAnchor.constraintEqualToAnchor(view.leadingAnchor, constant: 30).active = true
        customView.rightAnchor.constraintEqualToAnchor(space.leftAnchor, constant: -20).active = true
        secondView.leftAnchor.constraintEqualToAnchor(space.rightAnchor, constant: 20).active = true
        customView.widthAnchor.constraintGreaterThanOrEqualToConstant(150).active = true
        secondView.widthAnchor.constraintGreaterThanOrEqualToConstant(150).active = true
        secondView.trailingAnchor.constraintEqualToAnchor(view.trailingAnchor, constant: -30).active = true
        secondView.topAnchor.constraintEqualToAnchor(view.topAnchor, constant: 30).active = true
        customView.topAnchor.constraintEqualToAnchor(view.topAnchor, constant: 30).active = true
        customView.bottomAnchor.constraintEqualToAnchor(view.bottomAnchor, constant: -30).active = true
        secondView.bottomAnchor.constraintEqualToAnchor(view.bottomAnchor, constant: -30).active = true
        
    }
    
    func exampleTwoNSLayoutConstraint()
    {
        let customView:UIView = UIView();
        customView.backgroundColor = UIColor.magentaColor()
        view.addSubview(customView)
        customView.translatesAutoresizingMaskIntoConstraints = false
        let secondView = UIView()
        secondView.backgroundColor = UIColor.greenColor()
        secondView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(secondView)
        let views = ["iconImageView": customView,
            "appNameLabel": secondView]
        var allConstraints = [NSLayoutConstraint]()
        let iconVerticalConstraints = NSLayoutConstraint.constraintsWithVisualFormat(
            "V:|-23-[iconImageView(>=100)]-20-|",
            options: [],
            metrics: nil,
            views: views)
        allConstraints += iconVerticalConstraints
        let nameLabelVerticalConstraints = NSLayoutConstraint.constraintsWithVisualFormat(
            "V:|-23-[appNameLabel(iconImageView)]-20-|",
            options: [],
            metrics: nil,
            views: views)
        allConstraints += nameLabelVerticalConstraints
        let topRowHorizontalConstraints = NSLayoutConstraint.constraintsWithVisualFormat(
            "H:|-15-[iconImageView(>=100)]-[appNameLabel(iconImageView)]-15-|",
            options: [],
            metrics: nil,
            views: views)
        allConstraints += topRowHorizontalConstraints
        NSLayoutConstraint.activateConstraints(allConstraints)
    }
    


}

