//
//  ViewController.swift
//  LayoutAnchorFour
//
//  Created by padalingam agasthian on 15/03/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Any one method should be called
        // setUpNSLayoutConstraint()
        setUpAnchor()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func setUpAnchor()
    {
        let slider = UISlider()
        view.addSubview(slider)
        let space = UILayoutGuide()
        view.addLayoutGuide(space)
        slider.translatesAutoresizingMaskIntoConstraints = false
        let sliderOne = UISlider()
        view.addSubview(sliderOne)
        sliderOne.translatesAutoresizingMaskIntoConstraints = false
        slider.leadingAnchor.constraintEqualToAnchor(view.leadingAnchor, constant: 20).active = true
        slider.trailingAnchor.constraintEqualToAnchor(view.trailingAnchor, constant: -20).active = true
        slider.topAnchor.constraintEqualToAnchor(view.topAnchor, constant: 100).active = true
        sliderOne.leadingAnchor.constraintEqualToAnchor(view.leadingAnchor, constant: 20).active = true
        sliderOne.trailingAnchor.constraintEqualToAnchor(view.trailingAnchor, constant: -20).active = true
        slider.bottomAnchor.constraintEqualToAnchor(space.topAnchor, constant: -10).active = true
        sliderOne.topAnchor.constraintEqualToAnchor(space.bottomAnchor, constant: 10).active = true
        
    }
    
    func setUpNSLayoutConstraint()
    {
        let slider = UISlider()
        view.addSubview(slider)
        slider.translatesAutoresizingMaskIntoConstraints = false
        let sliderOne = UISlider()
        view.addSubview(sliderOne)
        sliderOne.translatesAutoresizingMaskIntoConstraints = false
        let horizonalContraints = NSLayoutConstraint(item: slider, attribute:
            .LeadingMargin, relatedBy: .Equal, toItem: view,
            attribute: .LeadingMargin, multiplier: 1.0,
            constant: 20)
        let horizonal2Contraints = NSLayoutConstraint(item: slider, attribute:
            .TrailingMargin, relatedBy: .Equal, toItem: view,
            attribute: .TrailingMargin, multiplier: 1.0, constant: -20)
        let pinTop = NSLayoutConstraint(item: slider, attribute: .Top, relatedBy: .Equal,
            toItem: view, attribute: .Top, multiplier: 1.0, constant: 100)
        let leading = NSLayoutConstraint(item: sliderOne, attribute: .Leading, relatedBy: .Equal, toItem: view, attribute: .Leading, multiplier: 1.0, constant: 20)
        let trailing = NSLayoutConstraint(item: sliderOne, attribute: .Trailing, relatedBy: .Equal, toItem: view, attribute: .Trailing, multiplier: 1.0, constant: -20)
        let vertical = NSLayoutConstraint(item: slider, attribute: .Bottom, relatedBy: .Equal, toItem: sliderOne, attribute: .Top, multiplier: 1.0, constant: -20)
        NSLayoutConstraint.activateConstraints([horizonalContraints, horizonal2Contraints,pinTop,leading,trailing,vertical])
    }
}

