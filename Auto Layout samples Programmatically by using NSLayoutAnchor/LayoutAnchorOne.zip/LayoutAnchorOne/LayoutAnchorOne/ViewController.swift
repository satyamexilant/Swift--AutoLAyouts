//
//  ViewController.swift
//  LayoutAnchorOne
//
//  Created by padalingam agasthian on 15/03/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Any one method should be called
         exampleNSLayoutConstraint()
         //  exampleNSLayoutAnchor()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func exampleNSLayoutConstraint()
    {
        let contentView = UIView()
        contentView.backgroundColor = UIColor.greenColor()
        let centerView = UIView()
        centerView.backgroundColor = UIColor.redColor()
        view = contentView
        centerView.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(centerView)
        self.view.addConstraint(NSLayoutConstraint(item: centerView, attribute: .Width, relatedBy: .Equal, toItem: self.view, attribute: .Width, multiplier: 0.5, constant: 0))
        self.view.addConstraint(NSLayoutConstraint(item: centerView, attribute: .Height, relatedBy: .Equal, toItem: self.view, attribute: .Height, multiplier: 0.5, constant: 0))
        self.view.addConstraint(NSLayoutConstraint(item: centerView, attribute: .CenterX, relatedBy: .Equal, toItem: self.view, attribute: .CenterX, multiplier: 1.0, constant: 0))
        self.view.addConstraint(NSLayoutConstraint(item: centerView, attribute: .CenterY, relatedBy: .Equal, toItem: self.view, attribute: .CenterY, multiplier: 1.0, constant: 0))
    }
    
    func exampleNSLayoutAnchor()
    {
        let contentView = UIView()
        contentView.backgroundColor = UIColor.greenColor()
        let centerView = UIView()
        centerView.backgroundColor = UIColor.redColor()
        view = contentView
        centerView.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(centerView)
        centerView.widthAnchor.constraintEqualToAnchor(view.widthAnchor, multiplier: 0.5).active = true
        centerView.heightAnchor.constraintEqualToAnchor(view.heightAnchor, multiplier:0.5).active = true
        centerView.centerXAnchor.constraintEqualToAnchor(view.centerXAnchor, constant: 0).active = true
        centerView.centerYAnchor.constraintEqualToAnchor(view.centerYAnchor, constant: 0).active = true
    }


}

