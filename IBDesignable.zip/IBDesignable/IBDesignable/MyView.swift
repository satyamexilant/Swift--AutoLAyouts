//
//  MyView.swift
//  IBDesignable
//
//  Created by padalingam agasthian on 17/03/16.
//  Copyright © 2016 padalingam agasthian. All rights reserved.
//

import UIKit

@IBDesignable class MyView: UIView
{
    var view                    : UIView!
    
    @IBOutlet weak var button   : UIButton!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var label    : UILabel!
    @IBOutlet weak var slider   : UISlider!
    @IBOutlet weak var `switch` : UISwitch!
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    
    @IBInspectable var borderWidth: CGFloat = 0
    {
        didSet
        {
            view.layer.borderWidth = borderWidth
        }
    }
    
    @IBInspectable var viewCornerRadius: CGFloat = 0
    {
        didSet
        {
            view.layer.cornerRadius = viewCornerRadius
        }
    }
    
    @IBInspectable var textlabelColor:UIColor = UIColor.blueColor()
    {
        didSet
        {
                label.textColor = textlabelColor
        }
    }
    
    @IBInspectable var segmentTint:UIColor = UIColor.blueColor()
    {
        didSet
        {
            segmentedControl.tintColor = segmentTint
        }
    }
    
    @IBInspectable var textShadowColor : UIColor = UIColor.brownColor()
    {
        didSet
        {
                label.shadowColor = textShadowColor
        }
    }
    
    @IBInspectable var sliderThumb : UIColor = UIColor.greenColor()
    {
        didSet
        {
            slider.thumbTintColor = sliderThumb
        }
    }
    
    @IBInspectable var switchTint : UIColor = UIColor.greenColor()
    {
        didSet
        {
            `switch`.tintColor = switchTint
        }
    }
    
    @IBInspectable var switchThumbTint : UIColor = UIColor.greenColor()
    {
        didSet
        {
            `switch`.thumbTintColor = switchThumbTint
        }
    }
    
    @IBInspectable var customImage:UIImage?
    {
        get
        {
            return imageView.image
        }
        set(customImage)
        {
            imageView.image = customImage
        }
    }
    
    @IBInspectable var buttonBackground:UIColor?
    {
        get
        {
            return UIColor.brownColor()
        }
        set(buttonBackground)
        {
            button.backgroundColor = buttonBackground
        }
    }
    override init(frame: CGRect)
    {
        super.init(frame: frame)
        xibSetup()
    }
    
    required init?(coder aDecoder: NSCoder)
    {
        super.init(coder: aDecoder)
        xibSetup()
    }
    
    func xibSetup()
    {
        view = loadViewFromNib()
        view.frame = bounds
        view.autoresizingMask = [UIViewAutoresizing.FlexibleWidth, UIViewAutoresizing.FlexibleHeight]
        addSubview(view)
    }
    
    func loadViewFromNib() -> UIView
    {
        let bundle = NSBundle(forClass: self.dynamicType)
        let nib = UINib(nibName: "MyView", bundle: bundle)
        let view = nib.instantiateWithOwner(self, options: nil)[0] as! UIView
        return view
    }

}
